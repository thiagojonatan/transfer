create table despesa_simplificada
(
    id                     bigint(20)  auto_increment  primary key,
    NMUNIDADEORCAMENTARIA  varchar(150)       null,
    NMCREDOR               varchar(150)       null,
    CPF_CNPJ               varchar(14)       null,
    VLDESPESA              DECIMAL(12, 2) null
);