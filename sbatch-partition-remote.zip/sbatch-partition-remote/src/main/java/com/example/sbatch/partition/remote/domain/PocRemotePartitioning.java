package com.example.sbatch.partition.remote.domain;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class PocRemotePartitioning {

    private String nomeCredor;
    private String documento;
    private BigDecimal valorDespesa;
    private String municipioUnidadeOrcamentaria;
    private Long id;

}
