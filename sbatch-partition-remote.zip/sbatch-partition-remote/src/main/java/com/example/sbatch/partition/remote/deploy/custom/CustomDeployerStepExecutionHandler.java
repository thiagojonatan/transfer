package com.example.sbatch.partition.remote.deploy.custom;


import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobInterruptedException;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.env.Environment;
import org.springframework.util.Assert;

@Slf4j
public class CustomDeployerStepExecutionHandler implements CommandLineRunner, ApplicationContextAware {

    //private static final Log logger = LogFactory.getLog(CustomDeployerStepExecutionHandler.class);

    private final JobExplorer jobExplorer;
    private final JobRepository jobRepository;
    private ApplicationContext applicationContext;

    @Value("${spring.batch.job.jobExecutionId:0}")
    private long jobExecutionId;

    @Value("${spring.batch.job.stepExecutionId:0}")
    private long stepExecutionId;

    @Value("${spring.batch.job.stepName:}")
    private String stepName;

    @Autowired
    private Environment env;

    public CustomDeployerStepExecutionHandler(JobExplorer jobExplorer, JobRepository jobRepository) {
        Assert.notNull(jobExplorer, "JobExplorer obrigatório");
        Assert.notNull(jobRepository, "JobRepository obrigatório");
        this.jobExplorer = jobExplorer;
        this.jobRepository = jobRepository;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    @Override
    public void run(String... args) throws Exception {

        // Dentro do método de validação do seu handler:
       /* String stepExecutionId = env.getProperty("spring.batch.job.stepExecutionId");
        String stepName = env.getProperty("spring.batch.job.stepName");*/

        // Só executa se receber os IDs via variáveis injetadas na inicialização do Pod efêmero
        if (this.stepExecutionId == 0 || this.stepName.isEmpty()) {
            log.info("Execucao padrao: Parametros de particao remota nao detectados. Ignorando Handler.");
            return;
        }
        /*if (stepExecutionId == null || stepName == null) {
            log.info("Execucao padrao: Parametros de particao remota nao detectados. Ignorando Handler.");
            return;
        }*/

        log.info("Iniciando Worker para processar StepExecutionId: {}", stepExecutionId);

        // Localiza o Step correspondente no contexto Spring do Worker de forma dinâmica
        Step step = this.applicationContext.getBean(stepName, Step.class);

        int tentativas = 3;
        StepExecution stepExecution = null;

        while (tentativas > 0) {
            stepExecution = jobExplorer.getStepExecution(jobExecutionId, stepExecutionId);
            if (stepExecution != null) {
                break;
            }
            log.warn("StepExecution {} não encontrado. Aguardando commit do Manager...", stepExecutionId);
            Thread.sleep(3000); // Aguarda 3 segundos antes de tentar de novo
            tentativas--;
        }

        if (stepExecution == null) {
            throw new IllegalArgumentException("Nenhum StepExecution encontrado no banco de metadados para o ID: " + stepExecutionId);
        }

        // Recupera o contexto do JobExecution de metadados salvo pelo nó pai/Manager
       /* StepExecution stepExecution = this.jobExplorer.getStepExecution(null, stepExecutionId);
        if (stepExecution == null) {
            throw new IllegalArgumentException("Nenhum StepExecution encontrado no banco de metadados para o ID: " + stepExecutionId);
        }*/

        try {
            // Executa localmente o chunk/módulo do step isolado
            step.execute(stepExecution);

            // CORREÇÃO: Verifica se o Spring Batch terminou o step com falha internamente
            if (stepExecution.getStatus() == BatchStatus.FAILED) {
                log.error("O processamento da partição do Worker falhou internamente para o ID: {}", stepExecutionId);
                // Opcional: relance uma exceção se quiser que o container feche com código de erro (Exit Code 1)
                throw new RuntimeException("Falha detectada na execução do Step do Worker.");
            } else {
                log.info("Partição finalizada com sucesso pelo Worker para o ID: {}", stepExecutionId);
            }
        } catch (JobInterruptedException e) {
            stepExecution.setStatus(BatchStatus.STOPPED);
            this.jobRepository.update(stepExecution);
        } catch (Throwable e) {
            stepExecution.addFailureException(e);
            stepExecution.setStatus(BatchStatus.FAILED);
            this.jobRepository.update(stepExecution);
        }
    }
}

