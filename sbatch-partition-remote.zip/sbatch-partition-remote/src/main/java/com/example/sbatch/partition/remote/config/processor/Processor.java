package com.example.sbatch.partition.remote.config.processor;

import com.example.sbatch.partition.remote.domain.PocRemotePartitioning;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class Processor implements ItemProcessor<PocRemotePartitioning, PocRemotePartitioning> {

    @Override
    public PocRemotePartitioning process(PocRemotePartitioning pocRemotePartitioning) {
        log.info("Nome do credor: {}, CNPJ: {}", pocRemotePartitioning.getNomeCredor(), pocRemotePartitioning.getDocumento());
        return pocRemotePartitioning;
    }
}
