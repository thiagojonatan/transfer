package com.example.sbatch.partition.remote.config.partitioned;

import lombok.Setter;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

@Component
public class ColumnRangePartitioner implements Partitioner {

    /*@Autowired
    @Qualifier("appDataSource")
    private DataSource dataSource;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public Map<String, ExecutionContext> partition(int gridSize) {

        Map<String, ExecutionContext> result = new HashMap<>();
        jdbcTemplate.setDataSource(this.dataSource);
        Integer max = jdbcTemplate.queryForObject("SELECT MAX(id) FROM despesa ", Integer.class);

        int qtdParticoes = max / gridSize;

        for (var i = 1; i <= gridSize; i++){
            var value = new ExecutionContext();
            result.put("partition" + i, value);

            int maxLocal = i*qtdParticoes;

            value.putInt("partition", i);
            value.putInt("minValue", i+(maxLocal - qtdParticoes));
            value.putInt("maxValue", maxLocal);

        }

        return result;
    }*/

    @Autowired
    @Qualifier("appDataSource")
    private DataSource dataSource;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public Map<String, ExecutionContext> partition(int gridSize) {

        jdbcTemplate.setDataSource(this.dataSource);
        Integer min = jdbcTemplate.queryForObject("SELECT MIN(id) FROM despesa", Integer.class);
        Integer max = jdbcTemplate.queryForObject("SELECT MAX(id) FROM despesa" , Integer.class);

        /*int min = 1;
        int max = 493038;*/

        int targetSize = (max - min) / gridSize + 1;

        Map<String, ExecutionContext> result = new HashMap<>();

        int number = 0;
        int start = min;
        int end = start + targetSize - 1;

        while (start <= max)
        {
            ExecutionContext value = new ExecutionContext();
            result.put("partition" + number, value);

            if(end >= max) {
                end = max;
            }

            value.putInt("minValue", start);
            value.putInt("maxValue", end);

            start += targetSize;
            end += targetSize;

            number++;
        }
        return result;
    }
}


