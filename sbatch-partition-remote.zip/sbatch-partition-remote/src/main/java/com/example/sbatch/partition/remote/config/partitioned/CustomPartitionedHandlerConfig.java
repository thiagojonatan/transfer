package com.example.sbatch.partition.remote.config.partitioned;

import com.example.sbatch.partition.remote.config.PartitionConfig;
import com.example.sbatch.partition.remote.deploy.custom.CustomDeployerPartitionHandler;
import lombok.AllArgsConstructor;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.partition.PartitionHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.deployer.resource.docker.DockerResource;
import org.springframework.cloud.deployer.resource.docker.DockerResourceLoader;
import org.springframework.cloud.deployer.spi.task.TaskLauncher;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.io.Resource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Configuration
@AllArgsConstructor(onConstructor_ = {@Autowired})
@EnableConfigurationProperties(value = {PartitionConfig.class})
public class CustomPartitionedHandlerConfig {

    private PartitionConfig partitionConfig;

    @Bean
    public PartitionHandler partitionHandler(TaskLauncher taskLauncher, JobExplorer jobExplorer) {
        Resource resource = new DockerResource(partitionConfig.getImage());

        CustomDeployerPartitionHandler handler = new CustomDeployerPartitionHandler(
                taskLauncher, jobExplorer, resource, "workerStep"
        );

        // 1. Configurações de Infraestrutura e Variáveis de Ambiente do Kubernetes
        Map<String, String> k8sProps = new HashMap<>();
        k8sProps.put("spring.cloud.deployer.kubernetes.memory", "1024Mi");
        k8sProps.put("spring.cloud.deployer.kubernetes.cpu", "1000m");

        // Passa o profile como variável de ambiente nativa do container no K8s
        k8sProps.put("spring.cloud.deployer.kubernetes.environmentVariables", "SPRING_PROFILES_ACTIVE=worker");

        // Injeção dos seus ConfigMaps e Secrets comentados anteriormente
        k8sProps.put("spring.cloud.deployer.kubernetes.configMapRefs", "sbatch-partition-config");
        k8sProps.put("spring.cloud.deployer.kubernetes.secretRefs", "sbatch-partition-secret");

        handler.setDeploymentProperties(k8sProps);

        // 2. Argumentos de Linha de Comando (CLI Args) repassados ao comando 'java -jar' do container
        List<String> commandLineArgs = new ArrayList<>();
        commandLineArgs.add("--spring.profiles.active=worker");

        // Opcional: Desativa inicializações automáticas redundantes no worker efêmero
        commandLineArgs.add("--spring.cloud.task.initialize-enabled=false");

        handler.setCommandLineArgs(commandLineArgs);
        handler.setMaxWorkers(5);

        return handler;
    }

}
