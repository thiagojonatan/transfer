package com.example.sbatch.partition.remote.deploy.custom;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.jspecify.annotations.NonNull;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.partition.PartitionHandler;
import org.springframework.batch.core.partition.StepExecutionSplitter;
import org.springframework.cloud.deployer.spi.core.AppDefinition;
import org.springframework.cloud.deployer.spi.core.AppDeploymentRequest;
import org.springframework.cloud.deployer.spi.task.TaskLauncher;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;

import java.util.*;

@Slf4j
public class CustomDeployerPartitionHandler implements PartitionHandler {

    //private static final Log logger = LogFactory.getLog(CustomDeployerPartitionHandler.class);

    private final TaskLauncher taskLauncher;
    private final JobExplorer jobExplorer;
    private final Resource resource;
    private final String stepName;

    @Setter
    private int maxWorkers = 10;
    @Setter
    private long pollInterval = 10000; // 10 segundos
    @Setter
    private long timeout = 0;
    @Setter
    private Map<String, String> deploymentProperties = new HashMap<>();
    @Setter
    private List<String> commandLineArgs = new ArrayList<>();
    @Setter
    private String applicationName = "batch-worker-task";

    public CustomDeployerPartitionHandler(TaskLauncher taskLauncher, JobExplorer jobExplorer,
                                          Resource resource, String stepName) {
        Assert.notNull(taskLauncher, "TaskLauncher não pode ser nulo");
        Assert.notNull(jobExplorer, "JobExplorer não pode ser nulo");
        Assert.notNull(resource, "Resource do container não pode ser nulo");
        Assert.hasText(stepName, "O nome do Step do Worker deve ser informado");
        this.taskLauncher = taskLauncher;
        this.jobExplorer = jobExplorer;
        this.resource = resource;
        this.stepName = stepName;

    }

    // Assinatura oficial e correta do Spring Batch 5
    @Override
    public Collection<StepExecution> handle(StepExecutionSplitter stepSplitter, StepExecution stepExecution) throws Exception {
        log.info("Iniciando metodo handle...");
        Assert.notNull(stepSplitter, "StepExecutionSplitter não pode ser nulo");
        Assert.notNull(stepExecution, "StepExecution do Manager não pode ser nulo");

        log.info("Executando metodo handle : {}", stepExecution.getId());

        // 1. Usa o splitter para gerar a lista de partições (StepExecutions dos Workers)
        Set<StepExecution> workerStepExecutions = stepSplitter.split(stepExecution, this.maxWorkers);

        if (workerStepExecutions == null || workerStepExecutions.isEmpty()) {
            return Collections.emptyList();
        }

        List<String> taskIds = new ArrayList<>();
        int currentWorkerCount = 0;

        // 2. Dispara um Job/Pod no Kubernetes para cada partição gerada
        for (StepExecution workerStepExecution : workerStepExecutions) {

            AppDeploymentRequest request = getAppDeploymentRequest(workerStepExecution);

            log.info("Disparando Worker no K8s para StepExecution ID: {}", workerStepExecution.getId());
            String id = this.taskLauncher.launch(request);
            taskIds.add(id);
            currentWorkerCount++;
        }

        // 3. Loop de Polling: Monitora o banco até que os passos paralelos mudem de status
        long startTime = System.currentTimeMillis();
        while (true) {
            boolean allFinished = true;
            for (StepExecution workerStepExecution : workerStepExecutions) {
                StepExecution updated = this.jobExplorer.getStepExecution(
                        stepExecution.getJobExecutionId(),
                        workerStepExecution.getId()
                );

                if (updated != null && updated.getStatus().isRunning()) {
                    allFinished = false;
                    break;
                }
            }

            if (allFinished) {
                log.info("Todos os Workers terminaram as execucoes das suas particoes.");
                break;
            }

            if (timeout > 0 && (System.currentTimeMillis() - startTime) > timeout) {
                throw new RuntimeException("Timeout atingido aguardando os Workers no cluster.");
            }

            //Thread.sleep(this.pollInterval);
        }

        // 4. Retorna o resultado atualizado coletado do banco de metadados
        List<StepExecution> results = new ArrayList<>();
        for (StepExecution workerStepExecution : workerStepExecutions) {
            results.add(this.jobExplorer.getStepExecution(stepExecution.getJobExecutionId(), workerStepExecution.getId()));
        }
        return results;
    }

    private @NonNull AppDeploymentRequest getAppDeploymentRequest(StepExecution workerStepExecution) {
        log.info("Nome do step: {}", workerStepExecution.getStepName());

        Map<String, String> appProps = new HashMap<>();
        /*appProps.put("spring.batch.job.stepExecutionId", String.valueOf(workerStepExecution.getId()));
        appProps.put("spring.batch.job.stepName", this.stepName);

        appProps.put("SPRING_BATCH_JOB_STEPEXECUTIONID", String.valueOf(workerStepExecution.getId()));
        appProps.put("SPRING_BATCH_JOB_STEPNAME", this.stepName);
        appProps.put("SPRING_PROFILES_ACTIVE", "worker");*/

        AppDefinition definition = new AppDefinition(this.applicationName + "-" + workerStepExecution.getId(), appProps);

        List<String> finalArgs = new ArrayList<>(this.commandLineArgs);
        finalArgs.add("--spring.batch.job.stepExecutionId=" + workerStepExecution.getId());
        finalArgs.add("--spring.batch.job.stepName=" + this.stepName);
        finalArgs.add("--spring.profiles.active=worker");
        // NOVIDADE CRUCIAL: Passa o ID da execução do Job pai para o Worker usar na busca!
        finalArgs.add("--spring.batch.job.jobExecutionId=" + workerStepExecution.getJobExecutionId());

        log.info("Argumentos finais que serao enviados ao Pod do Worker: {}", finalArgs);

        return new AppDeploymentRequest(definition, this.resource, this.deploymentProperties, finalArgs);
    }

}
