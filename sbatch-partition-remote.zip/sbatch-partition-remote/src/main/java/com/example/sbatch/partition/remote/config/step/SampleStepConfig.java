package com.example.sbatch.partition.remote.config.step;

import com.example.sbatch.partition.remote.config.partitioned.ColumnRangePartitioner;
import com.example.sbatch.partition.remote.config.writer.Writer;
import com.example.sbatch.partition.remote.domain.PocRemotePartitioning;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.partition.PartitionHandler;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

@Configuration
public class SampleStepConfig {

    @Autowired
    private Writer sbatchWriter;

    @Bean
    public Step workerStep(JdbcPagingItemReader<PocRemotePartitioning> pagingItemReader,
                           ItemProcessor<PocRemotePartitioning,
                                   PocRemotePartitioning> sampleProcessor,
                           PlatformTransactionManager transactionManager,
                           JobRepository jobRepository,
                           @Qualifier("appDataSource") DataSource dataSource) {
        return new StepBuilder("workerStep", jobRepository)
                .<PocRemotePartitioning, PocRemotePartitioning>chunk(5000, transactionManager)
                .reader(pagingItemReader)
                //.processor(sampleProcessor)
                .writer(sbatchWriter.writer(dataSource))
                .build();
    }

    @Bean
    public Step splitWorkers(PartitionHandler partitionHandler,
                             @Qualifier("workerStep") Step workerStep,
                             ColumnRangePartitioner columnRangePartitioner,
                             JobRepository jobRepository) throws Exception {
        return new StepBuilder("splitWorkers", jobRepository)
                .partitioner("workerStep", columnRangePartitioner)
                .gridSize(5)
                .step(workerStep)
                .partitionHandler(partitionHandler)
                .build();
    }
}
