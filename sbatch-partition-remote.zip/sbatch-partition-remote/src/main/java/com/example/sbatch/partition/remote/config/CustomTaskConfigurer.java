package com.example.sbatch.partition.remote.config;

import com.example.sbatch.partition.remote.deploy.custom.CustomTaskExecutionDaoFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cloud.task.configuration.DefaultTaskConfigurer;
import org.springframework.cloud.task.configuration.TaskConfigurer;
import org.springframework.cloud.task.repository.TaskExplorer;
import org.springframework.cloud.task.repository.TaskNameResolver;
import org.springframework.cloud.task.repository.TaskRepository;
import org.springframework.cloud.task.repository.dao.TaskExecutionDao;
import org.springframework.cloud.task.repository.support.SimpleTaskExplorer;
import org.springframework.cloud.task.repository.support.SimpleTaskNameResolver;
import org.springframework.cloud.task.repository.support.SimpleTaskRepository;
import org.springframework.cloud.task.repository.support.TaskExecutionDaoFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

@Component
public class CustomTaskConfigurer /*extends DefaultTaskConfigurer*/ {

    /*@Autowired
    public CustomTaskConfigurer(@Qualifier("springDataSource") DataSource dataSource) {
        super(dataSource);
    }*/


    @Bean
    public TaskConfigurer taskConfigurer(@Qualifier("springDataSource") DataSource dataSource) throws Exception {
        // Instancia a nossa classe polimórfica (ela é um TaskExecutionDaoFactoryBean válido)
        CustomTaskExecutionDaoFactoryBean factoryBean = new CustomTaskExecutionDaoFactoryBean(dataSource, "TASK_");
        factoryBean.getObject();
        // Os construtores originais agora aceitam o objeto perfeitamente
        TaskRepository taskRepository = new SimpleTaskRepository(factoryBean);
        TaskExplorer taskExplorer = new SimpleTaskExplorer(factoryBean);

        return new TaskConfigurer() {
            @Override
            public TaskRepository getTaskRepository() {
                return taskRepository;
            }

            @Override
            public PlatformTransactionManager getTransactionManager() {
                return new DefaultTaskConfigurer(dataSource).getTransactionManager();
            }

            @Override
            public TaskExplorer getTaskExplorer() {
                return taskExplorer;
            }

            @Override
            public DataSource getTaskDataSource() {
                return dataSource;
            }

            @Override
            public TaskNameResolver getTaskNameResolver() {
                return new SimpleTaskNameResolver();
            }

        };
    }

    @Bean
    public TaskExplorer taskExplorer(@Qualifier("springDataSource") DataSource dataSource) throws Exception {
        CustomTaskExecutionDaoFactoryBean factoryBean = new CustomTaskExecutionDaoFactoryBean(dataSource, "TASK_");
        factoryBean.getObject();
        // Expõe o Bean limpo exigido pelo inicializador global do Spring Cloud Task
        return new SimpleTaskExplorer(factoryBean);
    }

}
