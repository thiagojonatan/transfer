package com.example.sbatch.partition.remote.config.job;

import com.example.sbatch.partition.remote.deploy.custom.CustomDeployerStepExecutionHandler;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.batch.support.transaction.ResourcelessTransactionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.deployer.resource.docker.DockerResourceLoader;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import javax.sql.DataSource;

@Configuration
//@EnableBatchProcessing
public class JobConfig {

    @Autowired
    private ConfigurableApplicationContext context;

    @Autowired
    private DataSource dataSource;

    @Autowired
    public JobRepository jobRepository;

    @Bean
    public DockerResourceLoader getDockerResourceLoader() {
        return new DockerResourceLoader();
    }


    @Bean
    @Profile("!worker")
    public Job samplePartitionedJob(JobRepository jobRepository, Step splitWorkers) throws Exception {
        return new JobBuilder("samplePartitionedJob", jobRepository)
                .start(splitWorkers)
                .incrementer(new RunIdIncrementer())
                .build();
    }

   /* @Bean
    @Profile("worker")
    public DeployerStepExecutionHandler stepExecutionHandler(JobExplorer jobExplorer) {
        return new DeployerStepExecutionHandler(this.context, jobExplorer, this.jobRepository);
    }*/

    @Bean
    @Profile("worker")
    public CustomDeployerStepExecutionHandler stepExecutionHandler(JobExplorer jobExplorer) {
        return new CustomDeployerStepExecutionHandler(jobExplorer, this.jobRepository);
    }

    @Bean
    public JobRepository getJobRepository() throws Exception {
        var factory = new JobRepositoryFactoryBean();
        factory.setDataSource(dataSource);
        factory.setTransactionManager(new ResourcelessTransactionManager());
        factory.setIsolationLevelForCreate("ISOLATION_READ_UNCOMMITTED");
        factory.afterPropertiesSet();
        return factory.getObject();
    }
}
