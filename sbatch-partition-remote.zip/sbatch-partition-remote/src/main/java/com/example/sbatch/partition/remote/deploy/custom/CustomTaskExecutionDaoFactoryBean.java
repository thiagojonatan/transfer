package com.example.sbatch.partition.remote.deploy.custom;

import javax.sql.DataSource;
import java.lang.reflect.Field;
import java.sql.SQLException;

import io.fabric8.kubernetes.api.model.HTTPGetActionBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.database.support.DataFieldMaxValueIncrementerFactory;
import org.springframework.batch.item.database.support.DefaultDataFieldMaxValueIncrementerFactory;
import org.springframework.cloud.task.repository.dao.TaskExecutionDao;
import org.springframework.cloud.task.repository.dao.JdbcTaskExecutionDao;
import org.springframework.cloud.task.repository.support.DatabaseType;
import org.springframework.cloud.task.repository.support.TaskExecutionDaoFactoryBean;
import org.springframework.jdbc.support.MetaDataAccessException;

@Slf4j
public class CustomTaskExecutionDaoFactoryBean extends TaskExecutionDaoFactoryBean {

    private final DataSource dataSource;
    private final String tablePrefixx;

    public CustomTaskExecutionDaoFactoryBean(DataSource dataSource, String tablePrefix) {
        super(dataSource, tablePrefix);
        this.dataSource = dataSource;
        this.tablePrefixx = tablePrefix;
    }

    @Override
    public TaskExecutionDao getObject() throws Exception {

        // 1. Obtém o DAO nativo já construído pela classe pai
        JdbcTaskExecutionDao dao = (JdbcTaskExecutionDao) super.getObject();
        try {

            // 2. Instancia a factory corrigida usando o pacote moderno do Spring Batch 5
            DefaultDataFieldMaxValueIncrementerFactory correctFactory =
                    new DefaultDataFieldMaxValueIncrementerFactory(this.dataSource);
            correctFactory.setIncrementerColumnName("increment");

           /* // 3. Usa Reflection para acessar o campo privado interno "incrementerFactory" do DAO
            Field field = JdbcTaskExecutionDao.class.getDeclaredField("incrementerFactory");
            field.setAccessible(true);

            // 4. Força a substituição pelo objeto livre de erros
            field.set(dao, correctFactory);*/

            String databaseType = DatabaseType.fromMetaData(dataSource).name();
            assert dao != null;
            dao.setTaskIncrementer(correctFactory.getIncrementer(databaseType, this.tablePrefixx + "SEQ"));

            System.out.println("Alteracao de coluna setIncrementerColumnName executado");
        } catch (Exception e) {
            throw new IllegalStateException("Falha crítica ao injetar a IncrementerFactory corrigida via Reflection", e);
        }

        return dao;
    }
}

