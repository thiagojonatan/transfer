package com.example.sbatch.partition.remote.mapper;

import com.example.sbatch.partition.remote.domain.PocRemotePartitioning;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SampleRowMapper implements RowMapper<PocRemotePartitioning> {

	@Override
	public PocRemotePartitioning mapRow(ResultSet rs, int rowNum) throws SQLException {

		var result = new PocRemotePartitioning();

		result.setId(rs.getLong("id"));
		result.setNomeCredor(rs.getString("NMCREDOR"));
		result.setDocumento(rs.getString("CPF_CNPJ"));
		result.setValorDespesa(rs.getBigDecimal("VLDESPESA"));
		result.setMunicipioUnidadeOrcamentaria(rs.getString("NMUNIDADEORCAMENTARIA"));

		return result;
	}
}
