package com.example.sbatch.partition.remote.repository;


/*import com.example.sbatch.partition.remote.domain.PocRemotePartitioning;
import org.springframework.data.jpa.repository.JpaRepository;*/

/**
 * Interface de repositorio base do Dominio <code>PocRemotePartitioning</code>.
 */
/*public interface PocRemotePartitioningRepository extends JpaRepository<PocRemotePartitioning, Long> {

}*/
