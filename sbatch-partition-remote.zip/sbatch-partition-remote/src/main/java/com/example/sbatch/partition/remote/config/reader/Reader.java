package com.example.sbatch.partition.remote.config.reader;

import com.example.sbatch.partition.remote.domain.PocRemotePartitioning;
import com.example.sbatch.partition.remote.mapper.SampleRowMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.Order;
import org.springframework.batch.item.database.builder.JdbcPagingItemReaderBuilder;
import org.springframework.batch.item.database.support.MySqlPagingQueryProvider;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Configuration
public class Reader {

    /*@Bean
    @StepScope
    public JdbcPagingItemReader<PocRemotePartitioning> pagingItemReader(@Qualifier("appDataSource") DataSource dataSource,
                                                                        @Value("#{stepExecutionContext['minValue']}") int minValue,
                                                                        @Value("#{stepExecutionContext['maxValue']}") int maxValue) {

        var queryProvider = new MySqlPagingQueryProvider();
        queryProvider.setSelectClause("SELECT id, age, data, email, name");
        queryProvider.setFromClause("FROM user_domain");
        queryProvider.setWhereClause("id >= " + minValue + " and id <= " + maxValue);
        queryProvider.setSortKeys(Map.of("id", Order.ASCENDING));

        JdbcPagingItemReader<PocRemotePartitioning> reader = new JdbcPagingItemReader<>();
        reader.setDataSource(dataSource);
        reader.setFetchSize(5);
        reader.setRowMapper(new SampleRowMapper());
        reader.setQueryProvider(queryProvider);
        return reader;
    }*/

    @Bean
    @StepScope
    public JdbcPagingItemReader<PocRemotePartitioning> itemReader(@Qualifier("appDataSource") DataSource dataSource,
                                                          @Value("#{stepExecutionContext['minValue']}") Long minValue,
                                                          @Value("#{stepExecutionContext['maxValue']}") Long maxValue) {

        return new JdbcPagingItemReaderBuilder<PocRemotePartitioning>().name("transparenciaItemReader")
                .dataSource(dataSource)
                .selectClause("select id, NUANO,NUMES,NMMES,NUBIMESTRE,NUTRIMESTRE,NUQUADRIMESTRE,NUSEMESTRE,DTEMISSAODESPESA,SGLDESPESA,TPDESPESA,NREMPENHO,NRDOCUMENTODESPESA,CDUNIDADEORCAMENTARIA,NMUNIDADEORCAMENTARIA,CDUNIDADEGESTORA,NMUNIDADEGESTORA,CDCREDOR,NMCREDOR,CPF_CNPJ,NMTIPOCREDOR,CDFUNCAO,NMFUNCAO,CDSUBFUNCAO,NMSUBFUNCAO,CDPROGRAMA,NMPROGRAMA,CDACAO,NMACAO,CDFONTERECURSO,NMFONTERECURSO,CDCATEGORIA,NMCATEGORIA,CDGRUPONATUREZADESPESA,NMGRUPONATUREZADESPESA,CDMODALIDADEAPLICACAO,NMMODALIDADEAPLICACAO,CDELEMENTODESPESA,NMELEMENTODESPESA,CDSUBELEMENTODESPESA,NMSUBELEMENTODESPESA,VLDESPESA,HISTORICODESPESA")
                .fromClause("FROM despesa")
                .whereClause("where id >= " + minValue + " and id < " + maxValue)
                .sortKeys(Map.of("id", Order.ASCENDING))
                .rowMapper(new SampleRowMapper())
                .pageSize(40000)
                .build();
    }

}
