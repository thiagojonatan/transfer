package com.example.sbatch.partition.remote;

import io.fabric8.kubernetes.api.model.HTTPGetActionFluent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.task.configuration.EnableTask;
import io.fabric8.kubernetes.api.model.HTTPGetActionBuilder;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Map;


@EnableTask
@Slf4j
@SpringBootApplication
@EntityScan(basePackages = "com.example.sbatch.partition.remote.domain")
public class Application {
    public static void main(String... args) {
        mostrarParametrosIniciais(args);

        descobreJarClasse();

        descobrirExistentenciaWithNewPort();

        SpringApplication.run(Application.class, args);
    }

    private static void descobrirExistentenciaWithNewPort() {
        try {
            Class<?> clazz = HTTPGetActionBuilder.class;

            // 1. Identifica a origem física da classe
            java.net.URL location = clazz.getResource('/' + clazz.getName().replace('.', '/') + ".class");
            log.info("[DIAGNÓSTICO] A classe HTTPGetActionBuilder foi carregada de: {}", location);

            // 2. Tenta buscar o método específico via reflexão com o parâmetro Integer
            try {
                Method methodWithInteger = clazz.getMethod("withNewPort", Integer.class);
                log.info("[DIAGNÓSTICO] SUCESSO: O método withNewPort(Integer) EXISTE nesta classe.");
            } catch (NoSuchMethodException e) {
                log.error("[DIAGNÓSTICO] ERRO: O método withNewPort(Integer) NÃO EXISTE nesta classe!");

                // 3. Opcional: Listar quais assinaturas do 'withNewPort' realmente existem nela
                System.out.println("[DIAGNÓSTICO] Métodos 'withNewPort' alternativos encontrados:");
                for (Method m : clazz.getMethods()) {
                    if (m.getName().equals("withNewPort")) {
                        StringBuilder imprimir = new StringBuilder();
                        imprimir.append(" -> ").append(m.getName()).append("(");
                        for (Class<?> paramType : m.getParameterTypes()) {
                            imprimir.append(paramType.getSimpleName()).append(" ");
                        }
                        imprimir.append(")");

                        log.info(imprimir.toString());
                    }
                }
            }
        } catch (Exception e) {
            log.error("[DIAGNÓSTICO] Falha ao executar a inspeção por reflexão: {}", e.getMessage());
        }
    }

    private static void mostrarParametrosIniciais(String[] args) {
        Arrays.stream(args).toList().forEach( arg ->
                log.info("ESSE E O PARAMETRO INICIAL= {} ", arg)
        );


        Map<String, String> env = System.getenv();
        for (String envName : env.keySet()) {
            log.info("{} = {}", envName, env.get(envName));
        }
    }

    private static void descobreJarClasse() {
        Class<?> clazz = HTTPGetActionBuilder.class;
        java.net.URL location = clazz.getResource('/' + clazz.getName().replace('.', '/') + ".class");
        log.info("A CLASSE FOI CARREGADA DO JAR: {}", location);

        Class<?> clazzz = HTTPGetActionFluent.class;
        java.net.URL locationn = clazz.getResource('/' + clazz.getName().replace('.', '/') + ".class");
        log.info("A CLASSE FOI CARREGADA DO JAR: {}", locationn);
    }
}
