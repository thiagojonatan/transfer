package com.example.sbatch.partition.remote.config.writer;

import com.example.sbatch.partition.remote.domain.PocRemotePartitioning;
import lombok.AllArgsConstructor;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;

@Component
@AllArgsConstructor
public class Writer {

    public JdbcBatchItemWriter<PocRemotePartitioning> writer(DataSource dataSource) {
        String sql = "insert into despesa_simplificada (NMUNIDADEORCAMENTARIA, NMCREDOR, VLDESPESA, CPF_CNPJ) " +
                "values (?, ?, ?, ?)";
        return new JdbcBatchItemWriterBuilder<PocRemotePartitioning>().dataSource(dataSource)
                .sql(sql)
                .itemPreparedStatementSetter((item, ps) -> {
                    ps.setString(1, item.getMunicipioUnidadeOrcamentaria());
                    ps.setString(2, item.getNomeCredor());
                    ps.setBigDecimal(3, item.getValorDespesa());
                    ps.setString(4, item.getDocumento());
                })
                .assertUpdates(true)
                .build();
    }

}
