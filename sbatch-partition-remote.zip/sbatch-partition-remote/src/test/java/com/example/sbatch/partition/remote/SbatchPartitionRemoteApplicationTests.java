package com.example.sbatch.partition.remote;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbatchPartitionRemoteApplicationTests {

    @Test
    void contextLoads() {
    }

}
