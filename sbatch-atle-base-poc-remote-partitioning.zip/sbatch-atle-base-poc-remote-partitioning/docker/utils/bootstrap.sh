#!/bin/sh

# Impedir erros caso a aplicação carregue antes do Workload Identity
# Problema relatado em: https://cloud.google.com/kubernetes-engine/docs/troubleshooting/troubleshooting-security?hl=pt-br#troubleshoot-timeout
# APENAS SE DISABLE_METADATA_CHECK NÃO ESTIVER SETTADA
if [ -z "$DISABLE_METADATA_CHECK" ] ; then

    http_code=$(curl -LI http://169.254.169.254/computeMetadata/v1/instance/service-accounts/default/token -H 'Metadata-Flavor: Google' --retry 30 --retry-connrefused --retry-max-time 60 --connect-timeout 3 --fail --retry-all-errors -o /dev/null -w '%{http_code}\n' -s)
    if [ ${http_code} -ne 200 ]; then
        echo 'Retry limit exceeded. Failed to wait for metadata server to be available. Check if the gke-metadata-server Pod in the kube-system namespace is healthy.'
        exit 1
    fi

    echo "Metadados carregados com sucesso."

fi

# Start application
java -jar $JAVA_OPTS /deployment/application.jar
