# Serviço Spring Batch

Projeto de referência do framework Atlante para componentes do tipo SBATCH com as seguintes características:

* Leitura de arquivo CSV
* Gravação de dados em base de dados

# Pré Requisitos
Para que seja possível rodar essa aplicação é necessário atender alguns requisitos básicos.

- Java 11+
- Maven 3.8+

# Compilando e inicializando
Assim como todo projeto *Maven*, é necessário primeiramente realizarmos a geração dos fontes. Conforme o exemplo abaixo:

```bash
mvn clean install
```

Certifique-se de o repositório do Maven está corretamente configurado. Após os fontes terem sido gerados, basta executar o comando abaixo para inicializar a aplicação:

```
$ java -jar docker/sboot-atle-base-atom-poc-remote-partitioning.jar
```

Ou, se tiver importado por meio do IntelliJ, via classe `Application.java`.
Para validar se a aplicação inicializou com sucesso é necessario chamar o endpoint do *actuator* através do *link* abaixo:

```
http://localhost:9090/actuator/health
```

# Mostrando endpoints expostos
Assim que o projeto estiver sendo executado, é possível verificar as APIs expostas acessando a URL:

```
http://localhost:8080/swagger-ui/index.html
```

# Recurso database local em memória ()

```
http://localhost:8080/h2-console
```

# Documentação

Abaixo uma lista de links relevantes:

## Onboarding
- [Onboarding](https://confluence.bvnet.bv/display/TCloud/Onboarding+Atlante)
- [Documentação](https://confluence.bvnet.bv/display/TCloud/Atlante+Spring+Batch)
- [Referências](https://confluence.bvnet.bv/display/TCloud/Sbatch+Java#SbatchJava-Refer%C3%AAncias)

## Arquitetural
- [BVCLI](https://confluence.bvnet.bv/display/TCloud/BVCLI)
- [Modelo arquitetural](https://confluence.bvnet.bv/pages/viewpage.action?pageId=24159348)
- [Stack de tecnologias](https://confluence.bvnet.bv/pages/viewpage.action?pageId=24159474)

## Features
- [Atlante](https://confluence.bvnet.bv/display/TCloud/Features)
