package br.com.votorantim.atle.base.poc.remote.partitioning;

import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.boot.SpringApplication;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public class ApplicationTest {

    @Test
    void main() {

        try (MockedStatic<SpringApplication> utilities = Mockito.mockStatic(SpringApplication.class)) {
            utilities.when(() -> SpringApplication.run(Application.class))
                    .thenReturn(null);
            Application.main("0");
            assertNotNull(new Application());
        }
    }

}
