package br.com.votorantim.atle.base.poc.remote.partitioning.processor;

import br.com.votorantim.atle.base.poc.remote.partitioning.config.processor.Processor;
import br.com.votorantim.atle.base.poc.remote.partitioning.domain.PocRemotePartitioning;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ProcessorTest {

    private Processor processorMock = mock(Processor.class);
    private Processor processor = new Processor();

    @Test
    public void testSbatchProcessor() {
        PocRemotePartitioning pessoa = new PocRemotePartitioning("name", "email", "data", "age", 1L);
        when(processorMock.process(any())).thenReturn(pessoa);
        assertNotNull(processor.process(pessoa));
    }

}
