package br.com.votorantim.atle.base.poc.remote.partitioning.job;

import br.com.votorantim.atle.base.poc.remote.partitioning.config.job.JobConfig;
import br.com.votorantim.atle.base.poc.remote.partitioning.config.reader.Reader;
import br.com.votorantim.atle.base.poc.remote.partitioning.config.writer.Writer;
import br.com.votorantim.atle.base.poc.remote.partitioning.repository.PocRemotePartitioningRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DelegatingDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;

import javax.sql.DataSource;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class JobConfigTest {

    /*private JobConfig job;
    private JobBuilderFactory jobBuilderFactory;
    private StepBuilderFactory stepBuilderFactory;
    private Reader reader = new Reader();
    private Writer writer;
    private JpaTransactionManager jpaTransactionManager;
    private JobRepository repository = mock(JobRepository.class);
    private PocRemotePartitioningRepository userRepository = mock(PocRemotePartitioningRepository.class);
    private DataSource dataSource;

    @BeforeEach
    public void init() {
        dataSource = new DataSourceTransactionManager().getDataSource();
        jobBuilderFactory = new JobBuilderFactory(repository);
        stepBuilderFactory = new StepBuilderFactory(repository, new DataSourceTransactionManager());
        writer = new Writer(userRepository);
        jpaTransactionManager = new JpaTransactionManager();
        dataSource = new DelegatingDataSource();
        jpaTransactionManager.setDataSource(dataSource);
        job = new JobConfig(jobBuilderFactory, stepBuilderFactory, reader, writer);
    }

    @Test
    public void testJobConfig() {
        Writer writer = mock(Writer.class);
        when(writer.writer()).thenReturn(new RepositoryItemWriter<>());
        assertNotNull(job.job());
    }*/

}
