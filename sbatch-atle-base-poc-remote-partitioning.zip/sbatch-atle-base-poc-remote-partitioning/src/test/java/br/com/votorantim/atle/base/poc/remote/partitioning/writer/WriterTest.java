package br.com.votorantim.atle.base.poc.remote.partitioning.writer;

import br.com.votorantim.atle.base.poc.remote.partitioning.config.writer.Writer;
import br.com.votorantim.atle.base.poc.remote.partitioning.domain.PocRemotePartitioning;
import br.com.votorantim.atle.base.poc.remote.partitioning.repository.PocRemotePartitioningRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.batch.item.data.RepositoryItemWriter;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class WriterTest {

    private Writer sbatchWriter;
    private Writer sbatchWriterMock = mock(Writer.class);
    private PocRemotePartitioningRepository pocRemotePartitioningRepository = mock(PocRemotePartitioningRepository.class);

    @BeforeEach
    public void init() {
        sbatchWriter = new Writer(pocRemotePartitioningRepository);
    }

    @Test
    public void testWriterMethod() {
        RepositoryItemWriter<PocRemotePartitioning> itemWriter = mock(RepositoryItemWriter.class);
        when(sbatchWriterMock.writer()).thenReturn(itemWriter);
        assertNotNull(sbatchWriter.writer());
    }

}
