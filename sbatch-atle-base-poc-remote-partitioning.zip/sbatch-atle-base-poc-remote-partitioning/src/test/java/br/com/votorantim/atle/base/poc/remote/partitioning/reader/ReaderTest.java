package br.com.votorantim.atle.base.poc.remote.partitioning.reader;

import br.com.votorantim.atle.base.poc.remote.partitioning.config.reader.Reader;
import br.com.votorantim.atle.base.poc.remote.partitioning.domain.PocRemotePartitioning;
import br.com.votorantim.atle.base.poc.remote.partitioning.listener.ItemProcessorListener;
import org.junit.jupiter.api.Test;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.file.FlatFileItemReader;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

public class ReaderTest {

   /* private ItemProcessorListener itemProcessorListener = new ItemProcessorListener();
    private Reader read;

    @Test
    public void testFileReader() {
        itemProcessorListener.beforeProcess(new PocRemotePartitioning());
        itemProcessorListener.afterProcess(new PocRemotePartitioning(), new PocRemotePartitioning());
        read = new Reader();
        read.reader();
        read.reader().open(new ExecutionContext());
        FlatFileItemReader<PocRemotePartitioning> response = read.reader();
        assertNotNull(response);
    }

    @Test
    public void testFileReaderError() {
        itemProcessorListener.onProcessError(new PocRemotePartitioning(), new RuntimeException());
        ItemProcessorListener itemProcessorListenerMock = mock(ItemProcessorListener.class);
        doThrow(new RuntimeException()).when(itemProcessorListenerMock).onProcessError(any(PocRemotePartitioning.class), any(Exception.class));
        read = new Reader();
        read.reader();
        read.reader().open(new ExecutionContext());
        FlatFileItemReader<PocRemotePartitioning> response = read.reader();
        assertNotNull(response);
    }*/
}
