package br.com.votorantim.atle.base.poc.remote.partitioning.config;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
@NoArgsConstructor
@ConfigurationProperties(value = "batch.partition")
public class PartitionConfig {

    private String name;
    private String image;
}
