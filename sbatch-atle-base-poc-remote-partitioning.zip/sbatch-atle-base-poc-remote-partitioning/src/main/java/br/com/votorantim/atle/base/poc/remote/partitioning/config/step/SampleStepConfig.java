package br.com.votorantim.atle.base.poc.remote.partitioning.config.step;

import br.com.votorantim.atle.base.poc.remote.partitioning.config.partitioned.ColumnRangePartitioner;
import br.com.votorantim.atle.base.poc.remote.partitioning.config.writer.Writer;
import br.com.votorantim.atle.base.poc.remote.partitioning.domain.PocRemotePartitioning;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.partition.PartitionHandler;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SampleStepConfig {

    @Autowired
    public StepBuilderFactory stepBuilderFactory;

    @Autowired
    private Writer sbatchWriter;

    @Bean
    public Step workerStep(JdbcPagingItemReader pagingItemReader,
                           ItemProcessor sampleProcessor) {
        return stepBuilderFactory.get("workerStep")
                .<PocRemotePartitioning, PocRemotePartitioning>chunk(300)
                .reader(pagingItemReader)
                .processor(sampleProcessor)
                .writer(sbatchWriter.writer())
                .build();
    }

    @Bean
    public Step splitWorkers(PartitionHandler partitionHandler,
                             Step workerStep,
                             ColumnRangePartitioner columnRangePartitioner) throws Exception {
        return this.stepBuilderFactory.get("splitWorkers")
                .partitioner("workerStep", columnRangePartitioner)
                .step(workerStep)
                .partitionHandler(partitionHandler)
                .build();
    }
}
