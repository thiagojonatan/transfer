package br.com.votorantim.atle.base.poc.remote.partitioning.repository;

import br.com.votorantim.atle.base.poc.remote.partitioning.domain.PocRemotePartitioning;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Interface de repositorio base do Dominio <code>PocRemotePartitioning</code>.
 */
public interface PocRemotePartitioningRepository extends JpaRepository<PocRemotePartitioning, Long> {

}
