package br.com.votorantim.atle.base.poc.remote.partitioning.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;

/**
 * Classe de entidade de dominio <code>PocRemotePartitioning</code>.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "user_domain" )
public class PocRemotePartitioning {

    private String name;
    private String email;
    private String data;
    private String age;
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;
}
