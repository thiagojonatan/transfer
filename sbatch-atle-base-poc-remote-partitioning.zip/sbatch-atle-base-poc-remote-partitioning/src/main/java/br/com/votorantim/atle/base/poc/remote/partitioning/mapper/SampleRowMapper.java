package br.com.votorantim.atle.base.poc.remote.partitioning.mapper;

import br.com.votorantim.atle.base.poc.remote.partitioning.domain.PocRemotePartitioning;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SampleRowMapper implements RowMapper<PocRemotePartitioning> {

	@Override
	public PocRemotePartitioning mapRow(ResultSet rs, int rowNum) throws SQLException {

		return PocRemotePartitioning.builder()
			.id(rs.getLong("id"))
			.name(rs.getString("name"))
			.email(rs.getString("email"))
			.age(rs.getString("age"))
			.data(rs.getString("data"))
			.build();
	}
}
