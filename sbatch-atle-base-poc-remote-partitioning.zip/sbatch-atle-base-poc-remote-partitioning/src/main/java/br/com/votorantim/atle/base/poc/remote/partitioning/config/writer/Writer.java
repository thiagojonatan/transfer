package br.com.votorantim.atle.base.poc.remote.partitioning.config.writer;

import br.com.votorantim.atle.base.poc.remote.partitioning.domain.PocRemotePartitioning;
import br.com.votorantim.atle.base.poc.remote.partitioning.repository.PocRemotePartitioningRepository;
import lombok.AllArgsConstructor;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class Writer {

    private final PocRemotePartitioningRepository pocRemotePartitioningRepository;

    public RepositoryItemWriter<PocRemotePartitioning> writer() {
        RepositoryItemWriter<PocRemotePartitioning> writer = new RepositoryItemWriter<>();
        writer.setRepository(pocRemotePartitioningRepository);
        writer.setMethodName("save");
        return writer;
    }

}
