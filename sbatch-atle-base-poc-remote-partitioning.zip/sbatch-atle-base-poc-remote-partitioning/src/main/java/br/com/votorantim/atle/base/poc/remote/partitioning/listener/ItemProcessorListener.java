package br.com.votorantim.atle.base.poc.remote.partitioning.listener;

import br.com.votorantim.atle.base.poc.remote.partitioning.domain.PocRemotePartitioning;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ItemProcessListener;

@Slf4j
public class ItemProcessorListener implements ItemProcessListener<PocRemotePartitioning, PocRemotePartitioning> {

    @Override
    public void beforeProcess(PocRemotePartitioning pocRemotePartitioning) {
        log.info("ItemProcessor.beforeProcess");
    }

    @Override
    public void afterProcess(PocRemotePartitioning pocRemotePartitioning, PocRemotePartitioning pocRemotePartitioning2) {
        log.info("Item Process with success! {}", pocRemotePartitioning);
    }

    @Override
    public void onProcessError(PocRemotePartitioning pocRemotePartitioning, Exception e) {
        log.error("error processing message! " + e.getMessage());
    }

}
