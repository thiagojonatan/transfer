package br.com.votorantim.atle.base.poc.remote.partitioning.config.reader;

import br.com.votorantim.atle.base.poc.remote.partitioning.domain.PocRemotePartitioning;
import br.com.votorantim.atle.base.poc.remote.partitioning.mapper.SampleRowMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.Order;
import org.springframework.batch.item.database.support.MySqlPagingQueryProvider;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Configuration
public class Reader {

    @Bean
    @StepScope
    public JdbcPagingItemReader<PocRemotePartitioning> pagingItemReader(@Qualifier("appDataSource") DataSource dataSource,
                                                         @Value("#{stepExecutionContext['minValue']}") int minValue,
                                                         @Value("#{stepExecutionContext['maxValue']}") int maxValue) {

        Map<String, Order> sortKeys = new HashMap<>();
        sortKeys.put("id", Order.ASCENDING);

        var queryProvider = new MySqlPagingQueryProvider();
        queryProvider.setSelectClause("SELECT id, age, data, email, name");
        queryProvider.setFromClause("FROM user_domain");
        queryProvider.setWhereClause("id >= " + minValue + " and id <= " + maxValue);
        queryProvider.setSortKeys(Map.of("id", Order.ASCENDING));

        JdbcPagingItemReader<PocRemotePartitioning> reader = new JdbcPagingItemReader<>();
        reader.setDataSource(dataSource);
        reader.setFetchSize(1000);
        reader.setRowMapper(new SampleRowMapper());
        reader.setQueryProvider(queryProvider);
        return reader;
    }

}
