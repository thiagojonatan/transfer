package br.com.votorantim.atle.base.poc.remote.partitioning.config.processor;

import br.com.votorantim.atle.base.poc.remote.partitioning.domain.PocRemotePartitioning;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class Processor implements ItemProcessor<PocRemotePartitioning, PocRemotePartitioning> {

    @Override
    public PocRemotePartitioning process(PocRemotePartitioning pocRemotePartitioning) {
        log.info("name: {}, age: {}", pocRemotePartitioning.getName(), pocRemotePartitioning.getEmail());
        return pocRemotePartitioning;
    }
}
