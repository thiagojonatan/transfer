package br.com.votorantim.atle.base.poc.remote.partitioning.config.partitioned;

import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

@Component
public class ColumnRangePartitioner implements Partitioner {

    @Autowired
    @Qualifier("appDataSource")
    private DataSource dataSource;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public Map<String, ExecutionContext> partition(int gridSize) {

        Map<String, ExecutionContext> result = new HashMap<>();
        jdbcTemplate.setDataSource(this.dataSource);
        Integer max = jdbcTemplate.queryForObject("SELECT MAX(id) FROM user_domain ", Integer.class);

        int qtdParticoes = max / 10;

        Integer start = 1;
        Integer end = 10;

        for (var i = 1; i <= qtdParticoes; i++){
            var value = new ExecutionContext();
            result.put("partition" + i, value);

            value.putInt("partition", i);
            value.putInt("minValue", start);
            value.putInt("maxValue", end);

            start += 10;
            end += 10;
        }

        return result;
    }
}


